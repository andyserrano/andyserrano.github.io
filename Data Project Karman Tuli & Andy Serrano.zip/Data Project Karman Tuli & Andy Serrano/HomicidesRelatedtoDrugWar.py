"""
========
Karman Tuli & Andy Serrano
Period 2
2/10/17
========

A bar plot with errorbars and height labels on individual bars
"""
import numpy as np
import matplotlib.pyplot as plt

#amount of points in the graph
N = 8
homicide_means = (132.30, 140.61, 142.63, 144.65, 142.10, 149.65, 150.87, 148.31)
homicide_std = (2, 3, 4, 1, 2, 3, 3, 4)

ind = np.arange(N)  # the x locations for the groups
width = 0.30      # the width of the bars

fig, ax = plt.subplots()
rects1 = ax.bar(ind, homicide_means, width, color='r', yerr=homicide_std)

drugs_means = (5.95, 5.76, 6.70, 6.79, 5.54, 5.98, 7.99, 5.78)
drugs_std = (3, 5, 2, 3, 3, 1, 2, 4)
rects2 = ax.bar(ind + width, drugs_means, width, color='y', yerr=drugs_std)

# add some text for labels, titles
ax.set_ylabel('Number of Homocides (Drug-Related) Per Year [HUNDREDS]')
ax.set_title('Total Homicides vs Drug-Related Homicides / Yr [HUNDREDS]')
ax.set_xticks(ind + width / 2)
ax.set_xticklabels(('2000', '2001', '2002', '2003', '2004', '2005', '2006', '2007'))

ax.legend((rects1[0], rects2[0]), ('Total Homocides', 'Drug-Related Homicides'))


def autolabel(rects):
    
    #Attach a text label above each bar displaying its height
    #height of labels, titles, text
    for rect in rects:
        height = rect.get_height()
        ax.text(rect.get_x() + rect.get_width()/2., 0.85*height,
                '%d' % int(height),
                ha='center', va='bottom')

autolabel(rects1)
autolabel(rects2)

plt.show()